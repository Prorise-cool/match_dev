-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('供应链SCM-采购管理-采购计划', '2012', '1', 'plan', 'plan/plan/index', 1, 0, 'C', '0', '0', 'plan:plan:list', '#', 'admin', sysdate(), '', null, '供应链SCM-采购管理-采购计划菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('供应链SCM-采购管理-采购计划查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'plan:plan:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('供应链SCM-采购管理-采购计划新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'plan:plan:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('供应链SCM-采购管理-采购计划修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'plan:plan:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('供应链SCM-采购管理-采购计划删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'plan:plan:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('供应链SCM-采购管理-采购计划导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'plan:plan:export',       '#', 'admin', sysdate(), '', null, '');