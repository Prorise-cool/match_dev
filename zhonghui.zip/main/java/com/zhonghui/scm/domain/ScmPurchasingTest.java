package com.zhonghui.scm.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zhonghui.common.annotation.Excel;

/**
 * 供应链SCM-采购管理-采购计划对象 scm_purchasing_test
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
public class ScmPurchasingTest extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    @Excel(name = "编号")
    private Long id;

    /** 单据号 */
    @Excel(name = "单据号")
    private String documentNumber;

    /** 申请人id */
    private Long applicantId;

    /** 申请日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "申请日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date applicantDate;

    /** 申请状态:0未提交,1待审核,2已审核 */
    @Excel(name = "申请状态:0未提交,1待审核,2已审核")
    private Long applicantStatus;

    /** 审核人id */
    private Long approvedId;

    /** 审核日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "审核日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date approvedDate;

    /** 审核状态:0驳回,1通过 */
    @Excel(name = "审核状态:0驳回,1通过")
    private Long approvedStatus;

    /** 审核意见 */
    private String approvedComments;

    /** 申请人名称 */
    @Excel(name = "申请人名称")
    private String applicantName;

    /** 审核人名称 */
    @Excel(name = "审核人名称")
    private String approvedName;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setDocumentNumber(String documentNumber) 
    {
        this.documentNumber = documentNumber;
    }

    public String getDocumentNumber() 
    {
        return documentNumber;
    }
    public void setApplicantId(Long applicantId) 
    {
        this.applicantId = applicantId;
    }

    public Long getApplicantId() 
    {
        return applicantId;
    }
    public void setApplicantDate(Date applicantDate) 
    {
        this.applicantDate = applicantDate;
    }

    public Date getApplicantDate() 
    {
        return applicantDate;
    }
    public void setApplicantStatus(Long applicantStatus) 
    {
        this.applicantStatus = applicantStatus;
    }

    public Long getApplicantStatus() 
    {
        return applicantStatus;
    }
    public void setApprovedId(Long approvedId) 
    {
        this.approvedId = approvedId;
    }

    public Long getApprovedId() 
    {
        return approvedId;
    }
    public void setApprovedDate(Date approvedDate) 
    {
        this.approvedDate = approvedDate;
    }

    public Date getApprovedDate() 
    {
        return approvedDate;
    }
    public void setApprovedStatus(Long approvedStatus) 
    {
        this.approvedStatus = approvedStatus;
    }

    public Long getApprovedStatus() 
    {
        return approvedStatus;
    }
    public void setApprovedComments(String approvedComments) 
    {
        this.approvedComments = approvedComments;
    }

    public String getApprovedComments() 
    {
        return approvedComments;
    }
    public void setApplicantName(String applicantName) 
    {
        this.applicantName = applicantName;
    }

    public String getApplicantName() 
    {
        return applicantName;
    }
    public void setApprovedName(String approvedName) 
    {
        this.approvedName = approvedName;
    }

    public String getApprovedName() 
    {
        return approvedName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("documentNumber", getDocumentNumber())
            .append("applicantId", getApplicantId())
            .append("applicantDate", getApplicantDate())
            .append("applicantStatus", getApplicantStatus())
            .append("approvedId", getApprovedId())
            .append("approvedDate", getApprovedDate())
            .append("approvedStatus", getApprovedStatus())
            .append("approvedComments", getApprovedComments())
            .append("remark", getRemark())
            .append("applicantName", getApplicantName())
            .append("approvedName", getApprovedName())
            .toString();
    }
}
