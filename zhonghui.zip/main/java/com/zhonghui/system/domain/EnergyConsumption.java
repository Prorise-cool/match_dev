package com.zhonghui.system.domain;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zhonghui.common.annotation.Excel;

/**
 * 能耗记录对象 energy_consumption
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
public class EnergyConsumption extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 能耗记录编号 */
    private Long id;

    /** 记录日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "记录日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date date;

    /** 耗电量 */
    @Excel(name = "耗电量")
    private BigDecimal electricityConsumed;

    /** 耗水量 */
    @Excel(name = "耗水量")
    private BigDecimal waterConsumed;

    /** 碳排放量 */
    @Excel(name = "碳排放量")
    private BigDecimal carbonEmission;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setDate(Date date) 
    {
        this.date = date;
    }

    public Date getDate() 
    {
        return date;
    }
    public void setElectricityConsumed(BigDecimal electricityConsumed) 
    {
        this.electricityConsumed = electricityConsumed;
    }

    public BigDecimal getElectricityConsumed() 
    {
        return electricityConsumed;
    }
    public void setWaterConsumed(BigDecimal waterConsumed) 
    {
        this.waterConsumed = waterConsumed;
    }

    public BigDecimal getWaterConsumed() 
    {
        return waterConsumed;
    }
    public void setCarbonEmission(BigDecimal carbonEmission) 
    {
        this.carbonEmission = carbonEmission;
    }

    public BigDecimal getCarbonEmission() 
    {
        return carbonEmission;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("date", getDate())
            .append("electricityConsumed", getElectricityConsumed())
            .append("waterConsumed", getWaterConsumed())
            .append("carbonEmission", getCarbonEmission())
            .toString();
    }
}
