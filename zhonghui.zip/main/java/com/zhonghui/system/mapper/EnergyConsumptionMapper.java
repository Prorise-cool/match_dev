package com.zhonghui.system.mapper;

import java.util.List;
import com.zhonghui.system.domain.EnergyConsumption;

/**
 * 能耗记录Mapper接口
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
public interface EnergyConsumptionMapper 
{
    /**
     * 查询能耗记录
     * 
     * @param id 能耗记录主键
     * @return 能耗记录
     */
    public EnergyConsumption selectEnergyConsumptionById(Long id);

    /**
     * 查询能耗记录列表
     * 
     * @param energyConsumption 能耗记录
     * @return 能耗记录集合
     */
    public List<EnergyConsumption> selectEnergyConsumptionList(EnergyConsumption energyConsumption);

    /**
     * 新增能耗记录
     * 
     * @param energyConsumption 能耗记录
     * @return 结果
     */
    public int insertEnergyConsumption(EnergyConsumption energyConsumption);

    /**
     * 修改能耗记录
     * 
     * @param energyConsumption 能耗记录
     * @return 结果
     */
    public int updateEnergyConsumption(EnergyConsumption energyConsumption);

    /**
     * 删除能耗记录
     * 
     * @param id 能耗记录主键
     * @return 结果
     */
    public int deleteEnergyConsumptionById(Long id);

    /**
     * 批量删除能耗记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteEnergyConsumptionByIds(Long[] ids);
}
