package com.zhonghui.system.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zhonghui.system.mapper.EnergyConsumptionMapper;
import com.zhonghui.system.domain.EnergyConsumption;
import com.zhonghui.system.service.IEnergyConsumptionService;

/**
 * 能耗记录Service业务层处理
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
@Service
public class EnergyConsumptionServiceImpl implements IEnergyConsumptionService 
{
    @Autowired
    private EnergyConsumptionMapper energyConsumptionMapper;

    /**
     * 查询能耗记录
     * 
     * @param id 能耗记录主键
     * @return 能耗记录
     */
    @Override
    public EnergyConsumption selectEnergyConsumptionById(Long id)
    {
        return energyConsumptionMapper.selectEnergyConsumptionById(id);
    }

    /**
     * 查询能耗记录列表
     * 
     * @param energyConsumption 能耗记录
     * @return 能耗记录
     */
    @Override
    public List<EnergyConsumption> selectEnergyConsumptionList(EnergyConsumption energyConsumption)
    {
        return energyConsumptionMapper.selectEnergyConsumptionList(energyConsumption);
    }

    /**
     * 新增能耗记录
     * 
     * @param energyConsumption 能耗记录
     * @return 结果
     */
    @Override
    public int insertEnergyConsumption(EnergyConsumption energyConsumption)
    {
        return energyConsumptionMapper.insertEnergyConsumption(energyConsumption);
    }

    /**
     * 修改能耗记录
     * 
     * @param energyConsumption 能耗记录
     * @return 结果
     */
    @Override
    public int updateEnergyConsumption(EnergyConsumption energyConsumption)
    {
        return energyConsumptionMapper.updateEnergyConsumption(energyConsumption);
    }

    /**
     * 批量删除能耗记录
     * 
     * @param ids 需要删除的能耗记录主键
     * @return 结果
     */
    @Override
    public int deleteEnergyConsumptionByIds(Long[] ids)
    {
        return energyConsumptionMapper.deleteEnergyConsumptionByIds(ids);
    }

    /**
     * 删除能耗记录信息
     * 
     * @param id 能耗记录主键
     * @return 结果
     */
    @Override
    public int deleteEnergyConsumptionById(Long id)
    {
        return energyConsumptionMapper.deleteEnergyConsumptionById(id);
    }
}
