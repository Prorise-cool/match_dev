import request from '@/utils/request'

// 查询能耗记录列表
export function listConsumption(query) {
  return request({
    url: '/system/consumption/list',
    method: 'get',
    params: query
  })
}

// 查询能耗记录详细
export function getConsumption(id) {
  return request({
    url: '/system/consumption/' + id,
    method: 'get'
  })
}

// 新增能耗记录
export function addConsumption(data) {
  return request({
    url: '/system/consumption',
    method: 'post',
    data: data
  })
}

// 修改能耗记录
export function updateConsumption(data) {
  return request({
    url: '/system/consumption',
    method: 'put',
    data: data
  })
}

// 删除能耗记录
export function delConsumption(id) {
  return request({
    url: '/system/consumption/' + id,
    method: 'delete'
  })
}
