package com.zhonghui.scm.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zhonghui.scm.mapper.ScmPurchasingTestMapper;
import com.zhonghui.scm.domain.ScmPurchasingTest;
import com.zhonghui.scm.service.IScmPurchasingTestService;

/**
 * 供应链SCM-采购管理-采购计划Service业务层处理
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
@Service
public class ScmPurchasingTestServiceImpl implements IScmPurchasingTestService 
{
    @Autowired
    private ScmPurchasingTestMapper scmPurchasingTestMapper;

    /**
     * 查询供应链SCM-采购管理-采购计划
     * 
     * @param id 供应链SCM-采购管理-采购计划主键
     * @return 供应链SCM-采购管理-采购计划
     */
    @Override
    public ScmPurchasingTest selectScmPurchasingTestById(Long id)
    {
        return scmPurchasingTestMapper.selectScmPurchasingTestById(id);
    }

    /**
     * 查询供应链SCM-采购管理-采购计划列表
     * 
     * @param scmPurchasingTest 供应链SCM-采购管理-采购计划
     * @return 供应链SCM-采购管理-采购计划
     */
    @Override
    public List<ScmPurchasingTest> selectScmPurchasingTestList(ScmPurchasingTest scmPurchasingTest)
    {
        return scmPurchasingTestMapper.selectScmPurchasingTestList(scmPurchasingTest);
    }

    /**
     * 新增供应链SCM-采购管理-采购计划
     * 
     * @param scmPurchasingTest 供应链SCM-采购管理-采购计划
     * @return 结果
     */
    @Override
    public int insertScmPurchasingTest(ScmPurchasingTest scmPurchasingTest)
    {
        return scmPurchasingTestMapper.insertScmPurchasingTest(scmPurchasingTest);
    }

    /**
     * 修改供应链SCM-采购管理-采购计划
     * 
     * @param scmPurchasingTest 供应链SCM-采购管理-采购计划
     * @return 结果
     */
    @Override
    public int updateScmPurchasingTest(ScmPurchasingTest scmPurchasingTest)
    {
        return scmPurchasingTestMapper.updateScmPurchasingTest(scmPurchasingTest);
    }

    /**
     * 批量删除供应链SCM-采购管理-采购计划
     * 
     * @param ids 需要删除的供应链SCM-采购管理-采购计划主键
     * @return 结果
     */
    @Override
    public int deleteScmPurchasingTestByIds(Long[] ids)
    {
        return scmPurchasingTestMapper.deleteScmPurchasingTestByIds(ids);
    }

    /**
     * 删除供应链SCM-采购管理-采购计划信息
     * 
     * @param id 供应链SCM-采购管理-采购计划主键
     * @return 结果
     */
    @Override
    public int deleteScmPurchasingTestById(Long id)
    {
        return scmPurchasingTestMapper.deleteScmPurchasingTestById(id);
    }
}
