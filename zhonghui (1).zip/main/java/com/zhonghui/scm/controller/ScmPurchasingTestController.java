package com.zhonghui.scm.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zhonghui.common.annotation.Log;
import com.zhonghui.common.core.controller.BaseController;
import com.zhonghui.common.core.domain.AjaxResult;
import com.zhonghui.common.enums.BusinessType;
import com.zhonghui.scm.domain.ScmPurchasingTest;
import com.zhonghui.scm.service.IScmPurchasingTestService;
import com.zhonghui.common.utils.poi.ExcelUtil;
import com.zhonghui.common.core.page.TableDataInfo;

/**
 * 供应链SCM-采购管理-采购计划Controller
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
@RestController
@RequestMapping("/procurementPlan/procurementPlan")
public class ScmPurchasingTestController extends BaseController
{
    @Autowired
    private IScmPurchasingTestService scmPurchasingTestService;

    /**
     * 查询供应链SCM-采购管理-采购计划列表
     */
    @PreAuthorize("@ss.hasPermi('procurementPlan:procurementPlan:list')")
    @GetMapping("/list")
    public TableDataInfo list(ScmPurchasingTest scmPurchasingTest)
    {
        startPage();
        List<ScmPurchasingTest> list = scmPurchasingTestService.selectScmPurchasingTestList(scmPurchasingTest);
        return getDataTable(list);
    }

    /**
     * 导出供应链SCM-采购管理-采购计划列表
     */
    @PreAuthorize("@ss.hasPermi('procurementPlan:procurementPlan:export')")
    @Log(title = "供应链SCM-采购管理-采购计划", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ScmPurchasingTest scmPurchasingTest)
    {
        List<ScmPurchasingTest> list = scmPurchasingTestService.selectScmPurchasingTestList(scmPurchasingTest);
        ExcelUtil<ScmPurchasingTest> util = new ExcelUtil<ScmPurchasingTest>(ScmPurchasingTest.class);
        util.exportExcel(response, list, "供应链SCM-采购管理-采购计划数据");
    }

    /**
     * 获取供应链SCM-采购管理-采购计划详细信息
     */
    @PreAuthorize("@ss.hasPermi('procurementPlan:procurementPlan:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(scmPurchasingTestService.selectScmPurchasingTestById(id));
    }

    /**
     * 新增供应链SCM-采购管理-采购计划
     */
    @PreAuthorize("@ss.hasPermi('procurementPlan:procurementPlan:add')")
    @Log(title = "供应链SCM-采购管理-采购计划", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ScmPurchasingTest scmPurchasingTest)
    {
        return toAjax(scmPurchasingTestService.insertScmPurchasingTest(scmPurchasingTest));
    }

    /**
     * 修改供应链SCM-采购管理-采购计划
     */
    @PreAuthorize("@ss.hasPermi('procurementPlan:procurementPlan:edit')")
    @Log(title = "供应链SCM-采购管理-采购计划", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ScmPurchasingTest scmPurchasingTest)
    {
        return toAjax(scmPurchasingTestService.updateScmPurchasingTest(scmPurchasingTest));
    }

    /**
     * 删除供应链SCM-采购管理-采购计划
     */
    @PreAuthorize("@ss.hasPermi('procurementPlan:procurementPlan:remove')")
    @Log(title = "供应链SCM-采购管理-采购计划", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(scmPurchasingTestService.deleteScmPurchasingTestByIds(ids));
    }
}
