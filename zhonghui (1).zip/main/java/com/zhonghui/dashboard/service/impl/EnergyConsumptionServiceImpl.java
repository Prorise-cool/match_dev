package com.zhonghui.dashboard.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zhonghui.dashboard.mapper.EnergyConsumptionMapper;
import com.zhonghui.dashboard.domain.EnergyConsumption;
import com.zhonghui.dashboard.service.IEnergyConsumptionService;

/**
 * 能耗记录表Service业务层处理
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
@Service
public class EnergyConsumptionServiceImpl implements IEnergyConsumptionService 
{
    @Autowired
    private EnergyConsumptionMapper energyConsumptionMapper;

    /**
     * 查询能耗记录表
     * 
     * @param id 能耗记录表主键
     * @return 能耗记录表
     */
    @Override
    public EnergyConsumption selectEnergyConsumptionById(Long id)
    {
        return energyConsumptionMapper.selectEnergyConsumptionById(id);
    }

    /**
     * 查询能耗记录表列表
     * 
     * @param energyConsumption 能耗记录表
     * @return 能耗记录表
     */
    @Override
    public List<EnergyConsumption> selectEnergyConsumptionList(EnergyConsumption energyConsumption)
    {
        return energyConsumptionMapper.selectEnergyConsumptionList(energyConsumption);
    }

    /**
     * 新增能耗记录表
     * 
     * @param energyConsumption 能耗记录表
     * @return 结果
     */
    @Override
    public int insertEnergyConsumption(EnergyConsumption energyConsumption)
    {
        return energyConsumptionMapper.insertEnergyConsumption(energyConsumption);
    }

    /**
     * 修改能耗记录表
     * 
     * @param energyConsumption 能耗记录表
     * @return 结果
     */
    @Override
    public int updateEnergyConsumption(EnergyConsumption energyConsumption)
    {
        return energyConsumptionMapper.updateEnergyConsumption(energyConsumption);
    }

    /**
     * 批量删除能耗记录表
     * 
     * @param ids 需要删除的能耗记录表主键
     * @return 结果
     */
    @Override
    public int deleteEnergyConsumptionByIds(Long[] ids)
    {
        return energyConsumptionMapper.deleteEnergyConsumptionByIds(ids);
    }

    /**
     * 删除能耗记录表信息
     * 
     * @param id 能耗记录表主键
     * @return 结果
     */
    @Override
    public int deleteEnergyConsumptionById(Long id)
    {
        return energyConsumptionMapper.deleteEnergyConsumptionById(id);
    }
}
