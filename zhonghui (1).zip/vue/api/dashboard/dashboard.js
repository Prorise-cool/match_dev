import request from '@/utils/request'

// 查询能耗记录表列表
export function listDashboard(query) {
  return request({
    url: '/dashboard/dashboard/list',
    method: 'get',
    params: query
  })
}

// 查询能耗记录表详细
export function getDashboard(id) {
  return request({
    url: '/dashboard/dashboard/' + id,
    method: 'get'
  })
}

// 新增能耗记录表
export function addDashboard(data) {
  return request({
    url: '/dashboard/dashboard',
    method: 'post',
    data: data
  })
}

// 修改能耗记录表
export function updateDashboard(data) {
  return request({
    url: '/dashboard/dashboard',
    method: 'put',
    data: data
  })
}

// 删除能耗记录表
export function delDashboard(id) {
  return request({
    url: '/dashboard/dashboard/' + id,
    method: 'delete'
  })
}
