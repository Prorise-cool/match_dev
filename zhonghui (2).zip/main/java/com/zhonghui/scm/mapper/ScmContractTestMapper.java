package com.zhonghui.scm.mapper;

import java.util.List;
import com.zhonghui.scm.domain.ScmContractTest;

/**
 * 供应链SCM-销售管理-采购合同审核Mapper接口
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
public interface ScmContractTestMapper 
{
    /**
     * 查询供应链SCM-销售管理-采购合同审核
     * 
     * @param id 供应链SCM-销售管理-采购合同审核主键
     * @return 供应链SCM-销售管理-采购合同审核
     */
    public ScmContractTest selectScmContractTestById(Long id);

    /**
     * 查询供应链SCM-销售管理-采购合同审核列表
     * 
     * @param scmContractTest 供应链SCM-销售管理-采购合同审核
     * @return 供应链SCM-销售管理-采购合同审核集合
     */
    public List<ScmContractTest> selectScmContractTestList(ScmContractTest scmContractTest);

    /**
     * 新增供应链SCM-销售管理-采购合同审核
     * 
     * @param scmContractTest 供应链SCM-销售管理-采购合同审核
     * @return 结果
     */
    public int insertScmContractTest(ScmContractTest scmContractTest);

    /**
     * 修改供应链SCM-销售管理-采购合同审核
     * 
     * @param scmContractTest 供应链SCM-销售管理-采购合同审核
     * @return 结果
     */
    public int updateScmContractTest(ScmContractTest scmContractTest);

    /**
     * 删除供应链SCM-销售管理-采购合同审核
     * 
     * @param id 供应链SCM-销售管理-采购合同审核主键
     * @return 结果
     */
    public int deleteScmContractTestById(Long id);

    /**
     * 批量删除供应链SCM-销售管理-采购合同审核
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteScmContractTestByIds(Long[] ids);
}
