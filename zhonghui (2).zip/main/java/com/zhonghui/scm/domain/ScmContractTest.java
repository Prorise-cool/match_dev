package com.zhonghui.scm.domain;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.zhonghui.common.annotation.Excel;

/**
 * 供应链SCM-销售管理-采购合同审核对象 scm_contract_test
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
public class ScmContractTest extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 编号 */
    @Excel(name = "编号")
    private Long id;

    /** 合同编号 */
    @Excel(name = "合同编号")
    private String contractNumber;

    /** 申请编号 */
    @Excel(name = "申请编号")
    private Long applyCode;

    /** 客户id */
    @Excel(name = "客户id")
    private Long customId;

    /** 供应商id */
    @Excel(name = "供应商id")
    private Long supplierId;

    /** 联系人 */
    @Excel(name = "联系人")
    private String linkman;

    /** 金额 */
    @Excel(name = "金额")
    private Long money;

    /** 送货方式 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "送货方式", width = 30, dateFormat = "yyyy-MM-dd")
    private Date shipMethod;

    /** 签订日期 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "签订日期", width = 30, dateFormat = "yyyy-MM-dd")
    private Date signingDate;

    /** 申请人Id */
    @Excel(name = "申请人Id")
    private Long applyId;

    /** 申请时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "申请时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date applyTime;

    /** 申请状态 */
    @Excel(name = "申请状态")
    private String applyStatus;

    /** 审核人id */
    @Excel(name = "审核人id")
    private Long auditId;

    /** 审核时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "审核时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date auditTime;

    /** 审核状态 */
    @Excel(name = "审核状态")
    private String auditStatus;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setContractNumber(String contractNumber) 
    {
        this.contractNumber = contractNumber;
    }

    public String getContractNumber() 
    {
        return contractNumber;
    }
    public void setApplyCode(Long applyCode) 
    {
        this.applyCode = applyCode;
    }

    public Long getApplyCode() 
    {
        return applyCode;
    }
    public void setCustomId(Long customId) 
    {
        this.customId = customId;
    }

    public Long getCustomId() 
    {
        return customId;
    }
    public void setSupplierId(Long supplierId) 
    {
        this.supplierId = supplierId;
    }

    public Long getSupplierId() 
    {
        return supplierId;
    }
    public void setLinkman(String linkman) 
    {
        this.linkman = linkman;
    }

    public String getLinkman() 
    {
        return linkman;
    }
    public void setMoney(Long money) 
    {
        this.money = money;
    }

    public Long getMoney() 
    {
        return money;
    }
    public void setShipMethod(Date shipMethod) 
    {
        this.shipMethod = shipMethod;
    }

    public Date getShipMethod() 
    {
        return shipMethod;
    }
    public void setSigningDate(Date signingDate) 
    {
        this.signingDate = signingDate;
    }

    public Date getSigningDate() 
    {
        return signingDate;
    }
    public void setApplyId(Long applyId) 
    {
        this.applyId = applyId;
    }

    public Long getApplyId() 
    {
        return applyId;
    }
    public void setApplyTime(Date applyTime) 
    {
        this.applyTime = applyTime;
    }

    public Date getApplyTime() 
    {
        return applyTime;
    }
    public void setApplyStatus(String applyStatus) 
    {
        this.applyStatus = applyStatus;
    }

    public String getApplyStatus() 
    {
        return applyStatus;
    }
    public void setAuditId(Long auditId) 
    {
        this.auditId = auditId;
    }

    public Long getAuditId() 
    {
        return auditId;
    }
    public void setAuditTime(Date auditTime) 
    {
        this.auditTime = auditTime;
    }

    public Date getAuditTime() 
    {
        return auditTime;
    }
    public void setAuditStatus(String auditStatus) 
    {
        this.auditStatus = auditStatus;
    }

    public String getAuditStatus() 
    {
        return auditStatus;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("contractNumber", getContractNumber())
            .append("applyCode", getApplyCode())
            .append("customId", getCustomId())
            .append("supplierId", getSupplierId())
            .append("linkman", getLinkman())
            .append("money", getMoney())
            .append("shipMethod", getShipMethod())
            .append("signingDate", getSigningDate())
            .append("applyId", getApplyId())
            .append("applyTime", getApplyTime())
            .append("applyStatus", getApplyStatus())
            .append("auditId", getAuditId())
            .append("auditTime", getAuditTime())
            .append("auditStatus", getAuditStatus())
            .toString();
    }
}
