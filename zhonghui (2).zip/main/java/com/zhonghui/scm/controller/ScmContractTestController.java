package com.zhonghui.scm.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.zhonghui.common.annotation.Log;
import com.zhonghui.common.core.controller.BaseController;
import com.zhonghui.common.core.domain.AjaxResult;
import com.zhonghui.common.enums.BusinessType;
import com.zhonghui.scm.domain.ScmContractTest;
import com.zhonghui.scm.service.IScmContractTestService;
import com.zhonghui.common.utils.poi.ExcelUtil;
import com.zhonghui.common.core.page.TableDataInfo;

/**
 * 供应链SCM-销售管理-采购合同审核Controller
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
@RestController
@RequestMapping("/procurementContract/procurementContract")
public class ScmContractTestController extends BaseController
{
    @Autowired
    private IScmContractTestService scmContractTestService;

    /**
     * 查询供应链SCM-销售管理-采购合同审核列表
     */
    @PreAuthorize("@ss.hasPermi('procurementContract:procurementContract:list')")
    @GetMapping("/list")
    public TableDataInfo list(ScmContractTest scmContractTest)
    {
        startPage();
        List<ScmContractTest> list = scmContractTestService.selectScmContractTestList(scmContractTest);
        return getDataTable(list);
    }

    /**
     * 导出供应链SCM-销售管理-采购合同审核列表
     */
    @PreAuthorize("@ss.hasPermi('procurementContract:procurementContract:export')")
    @Log(title = "供应链SCM-销售管理-采购合同审核", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, ScmContractTest scmContractTest)
    {
        List<ScmContractTest> list = scmContractTestService.selectScmContractTestList(scmContractTest);
        ExcelUtil<ScmContractTest> util = new ExcelUtil<ScmContractTest>(ScmContractTest.class);
        util.exportExcel(response, list, "供应链SCM-销售管理-采购合同审核数据");
    }

    /**
     * 获取供应链SCM-销售管理-采购合同审核详细信息
     */
    @PreAuthorize("@ss.hasPermi('procurementContract:procurementContract:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(scmContractTestService.selectScmContractTestById(id));
    }

    /**
     * 新增供应链SCM-销售管理-采购合同审核
     */
    @PreAuthorize("@ss.hasPermi('procurementContract:procurementContract:add')")
    @Log(title = "供应链SCM-销售管理-采购合同审核", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody ScmContractTest scmContractTest)
    {
        return toAjax(scmContractTestService.insertScmContractTest(scmContractTest));
    }

    /**
     * 修改供应链SCM-销售管理-采购合同审核
     */
    @PreAuthorize("@ss.hasPermi('procurementContract:procurementContract:edit')")
    @Log(title = "供应链SCM-销售管理-采购合同审核", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody ScmContractTest scmContractTest)
    {
        return toAjax(scmContractTestService.updateScmContractTest(scmContractTest));
    }

    /**
     * 删除供应链SCM-销售管理-采购合同审核
     */
    @PreAuthorize("@ss.hasPermi('procurementContract:procurementContract:remove')")
    @Log(title = "供应链SCM-销售管理-采购合同审核", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(scmContractTestService.deleteScmContractTestByIds(ids));
    }
}
