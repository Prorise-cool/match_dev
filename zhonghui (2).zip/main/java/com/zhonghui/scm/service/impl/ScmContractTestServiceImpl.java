package com.zhonghui.scm.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zhonghui.scm.mapper.ScmContractTestMapper;
import com.zhonghui.scm.domain.ScmContractTest;
import com.zhonghui.scm.service.IScmContractTestService;

/**
 * 供应链SCM-销售管理-采购合同审核Service业务层处理
 * 
 * @author zhonghui
 * @date 2025-02-27
 */
@Service
public class ScmContractTestServiceImpl implements IScmContractTestService 
{
    @Autowired
    private ScmContractTestMapper scmContractTestMapper;

    /**
     * 查询供应链SCM-销售管理-采购合同审核
     * 
     * @param id 供应链SCM-销售管理-采购合同审核主键
     * @return 供应链SCM-销售管理-采购合同审核
     */
    @Override
    public ScmContractTest selectScmContractTestById(Long id)
    {
        return scmContractTestMapper.selectScmContractTestById(id);
    }

    /**
     * 查询供应链SCM-销售管理-采购合同审核列表
     * 
     * @param scmContractTest 供应链SCM-销售管理-采购合同审核
     * @return 供应链SCM-销售管理-采购合同审核
     */
    @Override
    public List<ScmContractTest> selectScmContractTestList(ScmContractTest scmContractTest)
    {
        return scmContractTestMapper.selectScmContractTestList(scmContractTest);
    }

    /**
     * 新增供应链SCM-销售管理-采购合同审核
     * 
     * @param scmContractTest 供应链SCM-销售管理-采购合同审核
     * @return 结果
     */
    @Override
    public int insertScmContractTest(ScmContractTest scmContractTest)
    {
        return scmContractTestMapper.insertScmContractTest(scmContractTest);
    }

    /**
     * 修改供应链SCM-销售管理-采购合同审核
     * 
     * @param scmContractTest 供应链SCM-销售管理-采购合同审核
     * @return 结果
     */
    @Override
    public int updateScmContractTest(ScmContractTest scmContractTest)
    {
        return scmContractTestMapper.updateScmContractTest(scmContractTest);
    }

    /**
     * 批量删除供应链SCM-销售管理-采购合同审核
     * 
     * @param ids 需要删除的供应链SCM-销售管理-采购合同审核主键
     * @return 结果
     */
    @Override
    public int deleteScmContractTestByIds(Long[] ids)
    {
        return scmContractTestMapper.deleteScmContractTestByIds(ids);
    }

    /**
     * 删除供应链SCM-销售管理-采购合同审核信息
     * 
     * @param id 供应链SCM-销售管理-采购合同审核主键
     * @return 结果
     */
    @Override
    public int deleteScmContractTestById(Long id)
    {
        return scmContractTestMapper.deleteScmContractTestById(id);
    }
}
